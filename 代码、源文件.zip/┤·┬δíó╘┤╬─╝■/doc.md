

## 介绍
![Alt text](mart/static/mart/Logo.png "Optional Logo") 

这个项目是一个库存管理
农场仓库系统，其中有一个部分供员工管理农场库存，另一个部分允许用户在线订购农产品。

该项目是在后端使用 Django 框架，在前端使用 JavaScript 构建的。
该应用程序是移动响应的。

## 描述
- 农场的注册员工 (Staff) 可以访问 Stock Manager Dashboard 查看所有产品的摘要、注册客户数量、
当前库存价值、已完成和未完成订单的数量以及已下订单的总价值。

    ![Alt text](mart/static/mart/stock-dash.PNG "Optional Logo") 

- 员工将可以访问销售汇总表，其中显示产品和相应的销售单位以及销售日期。

    ![Alt text](mart/static/mart/stock-sales.PNG "Optional Logo") 

- 工作人员还可以访问供应汇总表，显示向仓库供应产品的记录和相应的日期。

    ![Alt text](mart/static/mart/stock-supply.PNG "Optional Logo") 

- 每当仓库收到供应品时，工作人员也可以更新库存数量。

    ![Alt text](mart/static/mart/stock-edit.PNG "Optional Logo") 

-在线商店部分的用户可以订购农产品，提交产品评级和评论，创建产品愿望清单，按名称或描述或优势搜索产品，
将产品添加到购物车，结帐并成功下订单。

    ![Alt text](mart/static/mart/mart-logo.PNG "Optional Logo") 

- 每个成功的订单都会自动减少农场仓库中产品的库存数量。


以下特征证明了该项目相对于课程中其他先前项目的复杂性和独特性：

- 该项目从员工的角度将库存管理系统与基本的在线商店相结合。
  
  ![Alt text](mart/static/mart/stock-icon.PNG "Optional Logo")

- 应用程序前端开发 (CSS) 和移动响应能力。
- 合并摘要仪表板、销售和供应表，以及员工部分产品库存的编辑/更新功能。
- 该项目将登录用户的活动与商店库存联系起来，从而自动折旧产品的库存数量
下单成功后。
- 在此项目中，每个订单都有一个随机生成的 6 字符字母数字唯一 ID。
-相当大的努力致力于构建产品星级评定功能。商店的登录用户可以单击星形图标为每个产品提交评级。 Product 模型中内置了一个属性，用于计算所有提交的星级的平均值
对农产品进行评级并向用户呈现适当的星级。
- 将搜索功能从产品名称扩展到产品描述。查询为名称的一部分或描述的一部分返回适当的结果。
- Ability of users to switch (without reloading the page) between paginated view on the home page to viewing all available products on a single page

## 创建的文件内容
  - `mart` - 主应用目录。
    -`static/mart` 包含应用程序的 CSS 和 Javascript 文件。还包含特定图像，如徽标、主页轮播图像等
        - `cart.js` - 在 `cart.html` 模板中运行的脚本。
        - `category.js` - 在 `category.html` 中运行的脚本。
        - `checkout.js` - 在 `checkout.html` 模板中运行的脚本。
        - `index.js` - 在 `index.html` 模板中运行的脚本。
        - `index.js` - 在 `index.html` 模板中运行的脚本。
        - `product.js` - 在 `product.html` 模板中运行的脚本。
        - `wish.js` - 在 `wishlist.html` 模板中运行的脚本。
        - ``wish.js` - 在 `wishlist.html` 模板中运行的脚本。
    - `templates/mart` 包含所有应用程序模板。
        - `layout.html` - 扩展到所有其他模板的基本模板。
        - `cart.html` - 模板显示用户购物车和订单商品的详细信息。
        - `category.html` - 模板按所选类别显示仓库产品。
        - `checkout.html` - 模板允许用户提交他们的送货地址、借记卡详细信息，然后下订单。
        -`index.html` - 显示可用产品、评级和价格的仓库主页。
        - `login.html` - 显示用户登录视图的模板。
        - `product.html` - 模板显示产品详细信息、详细描述、价格、可用库存、产品评论、提交评论和星级评分的表格，
         “添加到购物车”功能和“添加到愿望清单”功能。
        - `register.html` - 显示新用户注册视图的模板。
        - `stock.html` - 模板显示库存管理仪表板和库存管理的所有相关功能。
    - `admin.py` - 包含所有应用程序模型的注册
    - `models.py` 包含项目中使用的六个模型。
    - `urls.py` - 包含所有应用程序 URL 以及项目的 `API` 路由。
    - `views.py` - 包含所有应用程序视图和 API 逻辑。
  - `media` - 此目录包含仓库中所有产品的照片。
  - `projectfinal` - 项目目录。
  - `db.sqlite3` - 包含应用程序数据库。
  


  
## 附加信息
出于网站管理目的，产品图片必须为 200 x 200 像素。


