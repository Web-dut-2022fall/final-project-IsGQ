from django.apps import AppConfig


class MartConfig(AppConfig):
    name = 'mart'
